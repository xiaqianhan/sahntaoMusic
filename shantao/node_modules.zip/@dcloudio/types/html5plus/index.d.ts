/// <reference path="../lib/HBuilderX.d.ts" />
/// <reference path="./plus.d.ts" />
