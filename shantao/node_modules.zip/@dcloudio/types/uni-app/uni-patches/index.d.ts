/// <reference path="./wx/index.d.ts" />
/// <reference path="./promisify/index.d.ts" />
