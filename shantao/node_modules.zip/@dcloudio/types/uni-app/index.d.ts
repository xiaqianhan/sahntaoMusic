/// <reference path="../lib/HBuilderX.d.ts" />
/// <reference path="../html5plus/plus.d.ts" />
/// <reference path="./common.d.ts" />
/// <reference path="./app.d.ts" />
/// <reference path="./page.d.ts" />
/// <reference path="./uni/index.d.ts" />
/// <reference path="./uni-patches/index.d.ts" />
/// <reference path="./cloud.d.ts" />

import UniApp = UniNamespace;
import UniCloud = UniCloudNamespace;
