/// <reference path="./getBatteryInfo.d.ts" />
/// <reference path="./MemoryWarning.d.ts" />
/// <reference path="./UserCaptureScreen.d.ts" />
/// <reference path="./Wifi.d.ts" />
