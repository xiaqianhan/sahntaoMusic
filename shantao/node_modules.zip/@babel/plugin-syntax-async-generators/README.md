# @babel/plugin-syntax-async-generators

> Allow parsing of async generator functions

See our website [@babel/plugin-syntax-async-generators](https://babeljs.io/docs/en/next/babel-plugin-syntax-async-generators.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-async-generators
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-async-generators --dev
```
