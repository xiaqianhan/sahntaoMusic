var OverloadYield = require("./OverloadYield.js");
function _awaitAsyncGenerator(value) {
  return new OverloadYield(value, 0);
}
module.exports = _awaitAsyncGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;